import csv

# Daten zum Schreiben in die CSV-Datei
data = [
    ['Name', 'Alter', 'Stadt'],
    ['Max Mustermann', 25, 'Berlin'],
    ['Anna Schmidt', 30, 'Hamburg'],
    ['Paul Müller', 28, 'München']
]

# Dateipfad für die CSV-Datei
csv_file_path = '/beispiel.csv'
path_to_csv_file="C:/Users/deniz/Masterthesis_git/python_skripte/python_skripte/csv"
# CSV-Datei schreiben
with open(path_to_csv_file+csv_file_path, mode='w', newline='') as file:
    writer = csv.writer(file)
    
    # Schreibe die Daten in die CSV-Datei
    for row in data:
        writer.writerow(row)

print(f'Die CSV-Datei wurde erfolgreich erstellt: {csv_file_path}')
